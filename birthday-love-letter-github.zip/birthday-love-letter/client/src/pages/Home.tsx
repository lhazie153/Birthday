import { useEffect, useMemo, useState } from "react";
import type { ChangeEvent, CSSProperties } from "react";
import {
  ArrowDown,
  ArrowRight,
  Camera,
  Check,
  ChevronDown,
  ChevronUp,
  Gift,
  Heart,
  LockKeyhole,
  Mail,
  Moon,
  Music2,
  Pause,
  Quote,
  Sparkles,
  Star,
  Sun,
  Upload,
  X,
} from "lucide-react";

const stars = Array.from({ length: 30 }, (_, index) => ({
  id: index,
  left: `${(index * 37) % 100}%`,
  top: `${(index * 61 + 9) % 100}%`,
  size: index % 5 === 0 ? 4 : index % 3 === 0 ? 3 : 2,
  delay: `${(index % 7) * 0.55}s`,
  duration: `${3.8 + (index % 5) * 0.65}s`,
}));

const loveThings = [
  "Your cute smile",
  "Your stupid little jokes ❤️",
  "The way you're so considerate of me",
  "Your adorable voice",
  "How you make me happy even when I'm having a horrible day",
  "The way you take care of me",
  "How you're so understanding of me",
  "How patient you are with me",
  "Your gorgeous face",
  "Your presence",
  "How respectful you are",
  "How kind you are",
  "You're the most amazing person",
  "Your caring nature",
  "Your words",
  "The way you were so shy the first time we met",
  "Your wonderful poems",
  "The way I could listen to you play the guitar all day",
  "Your positivity",
  "Your loyalty",
  "Your intentions",
  "The way you speak",
  "How comfortable I feel around you",
  "The way you always make me feel pretty",
  "The way you look beautiful in anything",
  "The way you put so much effort into your hobbies",
  "The way you're so creative",
  "How you're so considerate of everyone",
  "Your mesmerizing brown eyes",
  "Your unique and amazing personality",
  "The way you listen to me talk for hours",
  "The way you make me feel loved",
  "The way you made me believe love actually exists",
  "How you hold my hands",
  "How you explain stuff without making me feel dumb",
  "How gentle you are with me",
  "How I can come to you whenever I have problems",
  "How you're my safe space",
  "How you keep trying no matter how tired you are",
  "Your goals",
  "Your cute laugh",
  "Your warm, comforting hugs",
  "Your kisses",
  'The way you say "I love you"',
  "The way you look when you give me those sad puppy eyes ❤️ (heh bum)",
  "The time you give me",
  "All the effort you put into our relationship",
  "The thoughtful gifts you give me",
  "Your talents and skills",
  "Your thoughtfulness",
  "How smart you are",
  "The way you're so generous",
  "The way you'll come to see me even if it's only for a few minutes",
  "How dedicated you are to your dreams",
  "How adorable you look in any hairstyle",
  "How childish you are sometimes 😛",
  "Your silliness",
  "Your shyness",
  "Your compliments",
  "How you help me do stuff I have trouble with",
  "Your playfulness",
  "How you give me attention even when you're doing something that requires your full attention",
  "Your actions",
  "How cute you look and sound when you ask me to do something",
  "How honest you are",
  "How you talk about the things bothering you",
  "How you'll resolve things rather than ignoring them",
  "Your warm and soft touch",
  "Your company",
  "How you're gonna be my future partner 😜",
  "Your music taste",
  "Your style",
  "How you let me bite your face ❤️",
  "How you motivate me to become the best version of myself",
  "How you encourage me even when I'm feeling hopeless",
  "Your beautiful soul",
  "How you made me believe in soulmates",
  "How you're the colour in my bleak life",
  "How you're my light at the end of the tunnel",
  "How you let me lie on top of you",
  "How you've never used me",
  "How appreciated you make me feel",
  "Your consistency",
  "Your heart",
  "The way you trust me",
  "The fact that you chose me out of everyone",
  "How adorable you sound when talking about your interests",
  "How excited you get when you see things that you like",
  "The way you baby me",
  "The way you cuddle me",
  "The way you look at me when we're together",
  "How genuine you are",
  "The way I don't have to beg you to do simple things for me",
  "How effortlessly talented and smart you are",
  "How important you are to me",
  "Our calls",
  "Our late-night conversations",
  "Your reassurance",
  "Your love",
  "The way you're my adorable, talented, sweet, cute, caring, thoughtful baby.",
];

const openWhen = [
  {
    icon: <Heart size={18} fill="currentColor" />,
    title: "When you're sad",
    eyebrow: "a little hug in words",
    text: "Hi baby, if you opened this message, then that means that something's bothering you and making you sad. I might not know what the issue is, but I do know for a fact that whatever it is that's bothering you will go away with time. I know that you're strong and that you'll be able to push through it. But it's better if you tell me so that I can help you with whatever it is. Even if I can't help, I'll still be there for you every step of the way. I love you so much, baby. Don't let yourself feel down because of some problems, okay? I'm positive that whatever it is will eventually get better. ❤️",
  },
  {
    icon: <Moon size={18} />,
    title: "When you miss me",
    eyebrow: "look up at the same moon",
    text: "Hihi, if you opened this, then that means that you miss me, which also means that I definitely miss you more heh. Anyways, whatever it is, I'm sure that we'll probably get to meet sooner or later, so don't feel down because of this. I love you so so so much, baby. ❤️",
  },
  {
    icon: <Sun size={18} fill="currentColor" />,
    title: "When you've had a bad day",
    eyebrow: "for the days that feel too long",
    text: "Hi darling, if you opened this, then that means that you've had a bad day. Firstly, you should tell me the reason why your day went bad 😾😿. And if you can't, then remember that you're strong, smart, and absolutely wonderful, so don't let anyone or anything bother you. I'm sure that whatever it was that's bothering you will go away or disappear. Unless it's a person. Then I'll take care of them... 😾 I love you so much, baby. Mwahh. ❤️",
  },
];

const plans = [
  "Bake together",
  "Have a picnic",
  "Visit a place we've never been to together",
  "Make drawings of each other",
  "Take silly pictures together",
  "Make more memories together",
];

function scrollToId(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function playTinyMelody() {
  const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextClass) return;
  const context = new AudioContextClass();
  const notes = [261.63, 329.63, 392, 523.25, 392, 329.63];
  notes.forEach((frequency, index) => {
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    oscillator.type = "sine";
    oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(0.0001, context.currentTime + index * 0.18);
    gain.gain.exponentialRampToValueAtTime(0.08, context.currentTime + index * 0.18 + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + index * 0.18 + 0.6);
    oscillator.connect(gain).connect(context.destination);
    oscillator.start(context.currentTime + index * 0.18);
    oscillator.stop(context.currentTime + index * 0.18 + 0.62);
  });
  window.setTimeout(() => void context.close(), 1800);
}

export default function Home() {
  const [entered, setEntered] = useState(false);
  const [musicOn, setMusicOn] = useState(false);
  const [selectedLove, setSelectedLove] = useState(0);
  const [openLetter, setOpenLetter] = useState<number | null>(null);
  const [checkedPlans, setCheckedPlans] = useState<number[]>([]);
  const [surpriseVisible, setSurpriseVisible] = useState(false);
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [memoryPhotos, setMemoryPhotos] = useState<Record<string, string>>({});

  const completedPlans = checkedPlans.length;
  const loveCount = loveThings.length;
  const selectedLoveText = loveThings[selectedLove];
  const progress = useMemo(() => Math.round((completedPlans / plans.length) * 100), [completedPlans]);

  useEffect(() => {
    document.body.classList.toggle("is-locked", !entered);
    return () => document.body.classList.remove("is-locked");
  }, [entered]);

  function handlePhotoChange(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (file) setPhotoUrl(URL.createObjectURL(file));
  }

  function handleMemoryPhotoChange(key: string, event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (file) setMemoryPhotos((current) => ({ ...current, [key]: URL.createObjectURL(file) }));
  }

  function toggleMusic() {
    const next = !musicOn;
    setMusicOn(next);
    if (next) playTinyMelody();
  }

  function togglePlan(index: number) {
    setCheckedPlans((current) => current.includes(index) ? current.filter((item) => item !== index) : [...current, index]);
  }

  return (
    <main className="site-shell">
      <div className="grain" aria-hidden="true" />
      <div className="star-field" aria-hidden="true">
        {stars.map((star) => (
          <span key={star.id} className="star" style={{ left: star.left, top: star.top, width: star.size, height: star.size, animationDelay: star.delay, animationDuration: star.duration }} />
        ))}
      </div>

      {!entered && (
        <section className="entry-screen" aria-label="Birthday love letter opening">
          <div className="entry-orbit orbit-one" />
          <div className="entry-orbit orbit-two" />
          <div className="entry-content">
            <span className="eyebrow entry-eyebrow"><Sparkles size={14} /> a little midnight surprise</span>
            <div className="entry-heart" aria-hidden="true"><Heart size={34} fill="currentColor" /></div>
            <p className="entry-kicker">for my favourite person</p>
            <h1>I made something<br /><em>for you.</em></h1>
            <p className="entry-copy">A tiny corner of the internet, filled with all the things I never want you to forget.</p>
            <button className="enter-button" type="button" onClick={() => setEntered(true)}>
              <span>click to enter</span><Heart size={16} fill="currentColor" />
            </button>
            <span className="entry-note">best opened with your heart</span>
          </div>
          <span className="entry-side-note">01 / 07 &nbsp; — &nbsp; made with love</span>
        </section>
      )}

      {entered && (
        <>
          <header className="site-nav">
            <button className="brand-mark" type="button" onClick={() => scrollToId("top")} aria-label="Back to top"><span>for</span> my love <Heart size={14} fill="currentColor" /></button>
            <nav className="nav-links" aria-label="Main navigation">
              <button type="button" onClick={() => scrollToId("letter")}>the letter</button>
              <button type="button" onClick={() => scrollToId("memories")}>our story</button>
              <button type="button" onClick={() => scrollToId("love-list")}>100 reasons</button>
              <button type="button" onClick={() => scrollToId("open-when")}>open when</button>
            </nav>
            <button className={`music-toggle ${musicOn ? "active" : ""}`} type="button" onClick={toggleMusic} aria-label={musicOn ? "Turn soundtrack off" : "Play tiny soundtrack"}>
              {musicOn ? <Pause size={14} fill="currentColor" /> : <Music2 size={14} />}<span>{musicOn ? "playing" : "soundtrack"}</span>
            </button>
          </header>

          <section className="hero section-anchor" id="top">
            <div className="hero-corner top-left">BIRTHDAY LETTER<br /><span>15 · 09 · 2026</span></div>
            <div className="hero-corner top-right">VOL. 01<br /><span>just for you</span></div>
            <div className="hero-layout">
              <div className="hero-copy">
                <span className="eyebrow"><Sparkles size={14} /> Today's your special day baby</span>
                <h1>Happy birthday,<br /><em>my love.</em></h1>
                <p className="hero-lead">There are a million ways to say it, but I wanted to make you a place you can come back to whenever you need reminding.</p>
                <button className="text-link" type="button" onClick={() => scrollToId("letter")}>start reading <ArrowDown size={16} /></button>
              </div>
              <div className="hero-portrait" aria-label="A moonlit purple birthday illustration">
                <div className="moon-disc"><span>♡</span></div>
                <div className="portrait-glow" />
                <div className="portrait-caption"><span>my person</span><strong>my safe place</strong></div>
              </div>
            </div>
            <div className="hero-bottom"><span>scroll gently</span><div className="scroll-line" /><span>♡</span></div>
          </section>

          <section className="letter-section section-pad section-anchor" id="letter">
            <div className="section-label">02 <span>—</span> for you</div>
            <div className="letter-layout">
              <div className="section-intro">
                <span className="eyebrow">a note from me to you</span>
                <h2>Happy birthday,<br /><em>mon cher.</em></h2>
                <div className="ornament"><span /> <Heart size={13} fill="currentColor" /> <span /></div>
              </div>
              <div className="letter-paper">
                <Quote className="quote-mark" size={31} />
                <p className="letter-opening">I love you so much.</p>
                <p>I hope you know how grateful I am to have such an amazing person like you in my life. Your presence brings me so much joy and peace. No matter how miserable of a day I'm having, a simple conversation with you makes it a million times better.</p>
                <p>I'm so happy that I get to call you my partner. I hope you get everything you wish for, and I hope that I'll get to be there with you for all of it.</p>
                <p className="letter-ending">I truly love you so much, baby. <span>♡</span></p>
                <button className="paper-link" type="button" onClick={() => scrollToId("memories")}>keep reading <ArrowRight size={15} /></button>
                <span className="paper-signature">I love you so much</span>
              </div>
            </div>
          </section>

          <section className="memories-section section-pad section-anchor" id="memories">
            <div className="section-label">03 <span>—</span> our story</div>
            <div className="section-heading-row">
              <div><span className="eyebrow">little moments, big feelings</span><h2>Memory <em>lane</em></h2></div>
              <p className="section-aside">The beginning of us is still one of my favourite places to visit.</p>
            </div>
            <div className="timeline">
              <div className="timeline-line" />
              <article className="memory-stop first-stop"><span className="stop-dot">01</span><div className="memory-copy"><span className="memory-meta">#1 · the beginning</span><h3>And then there was <em>you.</em></h3><p>The day we got together {"<3"}</p></div><div className="memory-card memory-card-dark"><span className="memory-glyph">✦</span>{memoryPhotos.beginning ? <label className="memory-uploaded-wrap" htmlFor="memory-beginning"><img className="memory-uploaded-image" src={memoryPhotos.beginning} alt="The beginning" /><span>replace image</span><input id="memory-beginning" type="file" accept="image/*" onChange={(event) => handleMemoryPhotoChange("beginning", event)} /></label> : <label className="memory-picture-placeholder" htmlFor="memory-beginning"><Camera size={22} /><span>add our beginning picture</span><input id="memory-beginning" type="file" accept="image/*" onChange={(event) => handleMemoryPhotoChange("beginning", event)} /></label>}<strong>the first chapter</strong><small>softly, unexpectedly, completely</small></div></article>
              <article className="memory-stop reverse"><span className="stop-dot">02</span><div className="memory-card photo-card">{memoryPhotos.favourite ? <label className="memory-uploaded-wrap" htmlFor="memory-favourite"><img className="memory-uploaded-image" src={memoryPhotos.favourite} alt="Our favourite moment" /><span>replace image</span><input id="memory-favourite" type="file" accept="image/*" onChange={(event) => handleMemoryPhotoChange("favourite", event)} /></label> : <label className="photo-card-art" htmlFor="memory-favourite"><Heart size={35} fill="currentColor" /><span>add our favourite picture</span><input id="memory-favourite" type="file" accept="image/*" onChange={(event) => handleMemoryPhotoChange("favourite", event)} /></label>}<small>my bum 😼 i love you sm</small></div><div className="memory-copy"><span className="memory-meta">our favourite moment</span><h3>The day we <em>got together.</em></h3><p>Somehow, every ordinary day became a little more golden after that one.</p></div></article>
              <article className="memory-stop last-stop"><span className="stop-dot">03</span><div className="memory-copy"><span className="memory-meta">now ♡</span><h3>From here till <em>forever.</em></h3><p>More calls, more silly pictures, more reasons to choose each other.</p></div><div className="memory-card memory-card-outline">{memoryPhotos.now ? <label className="memory-uploaded-wrap" htmlFor="memory-now"><img className="memory-uploaded-image" src={memoryPhotos.now} alt="Us now" /><span>replace image</span><input id="memory-now" type="file" accept="image/*" onChange={(event) => handleMemoryPhotoChange("now", event)} /></label> : <label className="memory-now-placeholder" htmlFor="memory-now"><span>add a picture of us now</span><Heart size={23} fill="currentColor" /><input id="memory-now" type="file" accept="image/*" onChange={(event) => handleMemoryPhotoChange("now", event)} /></label>}<small>the best parts are still ahead</small></div></article>
            </div>
          </section>

          <section className="love-section section-pad section-anchor" id="love-list">
            <div className="section-label">04 <span>—</span> the love list</div>
            <div className="section-heading-row love-heading"><div><span className="eyebrow">tap a heart, keep a reason</span><h2>100 things I love<br /><em>about you.</em></h2></div><p className="section-aside">I could keep going forever, but here are a hundred places to start.</p></div>
            <div className="love-feature"><div className="love-feature-number">{String(selectedLove + 1).padStart(2, "0")} <span>/ {loveCount}</span></div><div className="love-feature-text"><span>reason no. {selectedLove + 1}</span><h3>{selectedLoveText}</h3></div><Heart className="feature-heart" size={48} fill="currentColor" /></div>
            <div className="heart-grid" aria-label="Reasons I love you">
              {loveThings.map((thing, index) => <button key={`${thing}-${index}`} className={`heart-button ${selectedLove === index ? "selected" : ""}`} type="button" onClick={() => setSelectedLove(index)} aria-label={`Reason ${index + 1}: ${thing}`}><Heart size={16} fill="currentColor" /><span>{String(index + 1).padStart(2, "0")}</span></button>)}
            </div>
          </section>

          <section className="open-section section-pad section-anchor" id="open-when">
            <div className="section-label">05 <span>—</span> little envelopes</div>
            <div className="section-heading-row"><div><span className="eyebrow">for whenever you need me</span><h2>Open <em>when…</em></h2></div><p className="section-aside">Little reminders, folded up and waiting for the exact right moment.</p></div>
            <div className="envelope-grid">
              {openWhen.map((letter, index) => <button key={letter.title} className={`envelope ${openLetter === index ? "opened" : ""}`} type="button" onClick={() => setOpenLetter(index)}><div className="envelope-flap" /><div className="envelope-seal"><Heart size={14} fill="currentColor" /></div><div className="envelope-label">{letter.icon}<span>{letter.title}</span></div><small>{letter.eyebrow}</small></button>)}
            </div>
          </section>

          <section className="plans-section section-pad section-anchor" id="plans">
            <div className="section-label">06 <span>—</span> our little plans</div>
            <div className="plans-layout"><div><span className="eyebrow">things we should do together</span><h2>A list for<br /><em>our next chapters.</em></h2><p className="plans-copy">Check them off as we make more tiny, wonderful memories.</p><div className="progress-wrap"><div className="progress-meta"><span>{completedPlans} of {plans.length} plans made</span><span>{progress}%</span></div><div className="progress-bar"><span style={{ width: `${progress}%` }} /></div></div></div><div className="checklist">{plans.map((plan, index) => <button key={plan} className={`check-item ${checkedPlans.includes(index) ? "done" : ""}`} type="button" onClick={() => togglePlan(index)}><span className="check-box">{checkedPlans.includes(index) && <Check size={14} />}</span><span>{plan}</span><ArrowRight className="check-arrow" size={15} /></button>)}</div></div>
          </section>

          <section className="final-section section-pad section-anchor" id="finale">
            <div className="final-orbit orbit-one" /><div className="final-orbit orbit-two" />
            <div className="section-label">07 <span>—</span> one more thing</div>
            {!surpriseVisible ? <div className="final-intro"><span className="eyebrow"><Gift size={14} /> saved for the end</span><h2>There's one<br /><em>more thing…</em></h2><p>One last little secret, if you promise to read it with your whole heart.</p><button className="surprise-button" type="button" onClick={() => setSurpriseVisible(true)}>open the final surprise <Sparkles size={16} /></button></div> : <div className="surprise-reveal"><div className="reveal-tag">for my adorable Ugyi ♡</div><h2>If I could give you anything<br />for your birthday…</h2><p className="reveal-lead">I'd give you the ability to see yourself through my eyes for just a moment.</p><p>Maybe then you'd understand why I love you so much.</p><div className="final-photo-frame">{photoUrl ? <img src={photoUrl} alt="Your favorite memory" /> : <div className="photo-placeholder"><Camera size={27} /><span>your favorite photo<br /><small>belongs here</small></span></div>}<label className="photo-upload" htmlFor="favorite-photo"><Upload size={14} /> {photoUrl ? "change photo" : "add a favorite photo"}</label><input id="favorite-photo" type="file" accept="image/*" onChange={handlePhotoChange} /></div><p className="final-message">Happy Birthday, my adorable Ugyi. <span>♡</span></p><p className="final-thanks">Thank you for being my partner<br />and choosing me.</p><div className="final-signature">I love you so much, darling. <Heart size={14} fill="currentColor" /></div></div>}
          </section>

          <footer className="site-footer"><span>made under the same moon</span><Heart size={13} fill="currentColor" /><span>for my favourite person</span></footer>

          {openLetter !== null && <div className="modal-backdrop" role="presentation" onClick={() => setOpenLetter(null)}><article className="open-letter-modal" role="dialog" aria-modal="true" aria-labelledby="open-letter-title" onClick={(event) => event.stopPropagation()}><button className="modal-close" type="button" onClick={() => setOpenLetter(null)} aria-label="Close letter"><X size={18} /></button><div className="modal-icon">{openWhen[openLetter].icon}</div><span className="eyebrow">{openWhen[openLetter].eyebrow}</span><h2 id="open-letter-title">{openWhen[openLetter].title}</h2><div className="modal-rule" /><p>{openWhen[openLetter].text}</p><div className="modal-signoff">always here <Heart size={14} fill="currentColor" /></div></article></div>}
        </>
      )}
    </main>
  );
}
